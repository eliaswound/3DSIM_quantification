function [ f, xb ] = GaussianStrip( x )
%GAUSSIANSTRIP creates an image with a gaussian wall of height 1.0 and
%same dimensions as the grids 'xg' and 'yg'
% arguments:
%   x     input variables for the ray describing the gaussian:
%            1  x-position of the start point of the ray
%            2  y-position of the start point of the ray
%            3  angle between this ray and the x-axis
%            4  width of the gaussian 
% results:
%   f     the returned grey image
%   xb        the jacobian of the image with respect to the input variable x
%             this is optional and only calculated, if requested

  global xg yg; % load roi grids from global scope

  % calculate orientated distance to ray
  d = ( yg - x(2) ) .* cos(x(3)) + ( x(1) - xg ) .* sin(x(3));
  if nargout == 1
    % use this for gaussian
    f = exp( - d.^2 ./ x(4) );
  else
    xb = zeros( numel(xg), 4 ); % preallocate memory
    
    % calculate intermediate variables and value of function  
    temp = d.^2 ./ x(4);
    f = exp( -temp );
    tempb = -( f ./ x(4) );
    db = 2.0 .* d .* tempb;
    
    % calculate jacobian
    xb(:,1) = sin(x(3)) .* db;
    xb(:,2) = - cos(x(3)) .* db;
    xb(:,3) = ( (x(1)-xg) .* cos(x(3)) - (yg-x(2)) .* sin(x(3)) ) .* db;
    xb(:,4) = -temp .* tempb;
  end
end