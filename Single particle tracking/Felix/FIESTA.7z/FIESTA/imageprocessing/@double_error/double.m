function d = double( e )
%DOUBLE returns the value of the double_error variable in double format
  
  d = double( e.value );
end
