function e = uminus( e )
%UMINES returns the unary minus value of e

  e.value = -e.value;
end