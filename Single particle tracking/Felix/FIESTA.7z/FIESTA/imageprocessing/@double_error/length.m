function n = length( a )
%LENGTH returns the number of elements on the largest axis in the array a

  n = length( a.value );
end