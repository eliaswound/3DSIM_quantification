function r = gt( a, b )
%GT checks, if the value of a is greater than the value of b
  
  r = double( a.value ) > double( b.value );
end
