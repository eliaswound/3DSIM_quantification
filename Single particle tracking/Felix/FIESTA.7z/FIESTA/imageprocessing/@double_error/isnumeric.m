function b = isnumeric( a )
%ISNUMERIC checks, if a is a numeric value

  b = isnumeric( a.value );
end