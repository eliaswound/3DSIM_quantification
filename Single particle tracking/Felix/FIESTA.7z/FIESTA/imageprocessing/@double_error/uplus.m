function e = uplus( e )
%UPLUS returns the unary plus value of e
