function r = lt( a, b )
  r = double( a.value ) < double( b.value );
end
