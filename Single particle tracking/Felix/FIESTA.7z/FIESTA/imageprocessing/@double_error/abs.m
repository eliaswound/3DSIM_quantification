function e = abs( e )
%ABS returns the absolute value of the double_error variable
  e.value = abs( e.value );
end
