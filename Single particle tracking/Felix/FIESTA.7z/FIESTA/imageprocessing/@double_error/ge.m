function r = ge( a, b )
%GE checks, if the value of a is greater or equal to the value of b
  
  r = double( a.value ) >= double( b.value );
end
