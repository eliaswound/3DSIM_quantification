function n = numel( a )
%NUMEL returns the number of elements in the array a

  n = numel( a.value );
end