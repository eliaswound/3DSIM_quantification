function e = real( e )
%REAL returnes the real parts of the value and error of the input

  e.value = real( e.value );
  e.error = real( e.error );
end
